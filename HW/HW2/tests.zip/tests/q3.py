OK_FORMAT = True

test = {   'name': 'q3',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> abs(right_x - 38.302) < 1e-05\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(bottom_length - 76.604) < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
