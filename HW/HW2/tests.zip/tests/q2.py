OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> q2_data[0].strip().lower() == 'x'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> q2_data[1].strip().lower() == 'increasing'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> q2_data[2].strip().lower() == 'y'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> q2_data[3].strip().lower() == 'decreasing'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> q2_data[4].strip().lower() == 's'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> q2_data[5].strip().lower() == 'n'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> int(q2_data[6].strip()) == 270\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
