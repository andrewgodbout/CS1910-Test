OK_FORMAT = True

test = {   'name': 'q4',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> abs(cone_bottom_x) < 1e-05\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(cone_side_length - 203.63458253) < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
