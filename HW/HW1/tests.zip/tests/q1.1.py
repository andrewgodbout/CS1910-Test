OK_FORMAT = True

test = {   'name': 'q1.1',
    'points': 1,
    'suites': [{'cases': [{'code': ">>> q11name.lower().strip() == 'Aaron'.lower()\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
