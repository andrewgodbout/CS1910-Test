OK_FORMAT = True

test = {'name': 'q1.3', 'points': 1, 'suites': [{'cases': [{'code': '>>> q13palindrome_count == 6\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
